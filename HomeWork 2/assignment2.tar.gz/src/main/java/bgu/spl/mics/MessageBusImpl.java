package bgu.spl.mics;

import java.util.Collection;
import java.util.Enumeration;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
/**
 * The {@link MessageBusImpl class is the implementation of the MessageBus interface.
 * Write your implementation here!
 * Only private fields and methods can be added to this class.
 */
public class MessageBusImpl implements MessageBus {

	//concurrent hash map with type, linked blocking queues for the events and brodcasts(messages)
	private ConcurrentHashMap<Class, LinkedBlockingQueue<MicroService>> events = new ConcurrentHashMap<>();
	private ConcurrentHashMap<Class, LinkedBlockingQueue<MicroService>> broadcasts = new ConcurrentHashMap<>();

	//concurrent hash map of event, Future
	private ConcurrentHashMap<Event, Future> futureList = new ConcurrentHashMap<>();

	//concurrent hash for microservices
	private ConcurrentHashMap<MicroService, LinkedBlockingQueue<Message>> serviceList = new ConcurrentHashMap<>();

	private static MessageBusImpl bus = null;

	@Override
	public <T> void subscribeEvent(Class<? extends Event<T>> type, MicroService m) {

		//microservice has a queue
		if(events.containsKey(type)) {
			if(!(events.get(type)).contains(m)) {
				try {
					(events.get(type)).put(m);
				}
				catch(InterruptedException e) {

				}
			}
		}
		//microservice needs a queue
		else {
			LinkedBlockingQueue<MicroService> queue = new LinkedBlockingQueue<>(100);
			try {
				queue.put(m);
			}
			catch (InterruptedException e) {

			}
			events.put(type, queue);
		}
	}

	@Override
	public void subscribeBroadcast(Class<? extends Broadcast> type, MicroService m) {

		//microservice has a queue
		if(broadcasts.containsKey(type)) {
			System.out.println(type.getName() + "is contained");
			if(!(broadcasts.get(type)).contains(m)) {
				try {
					(broadcasts.get(type)).put(m);
				}
				catch(InterruptedException e) {

				}
			}
		}
		//microservice needs a queue
		else {
			LinkedBlockingQueue<MicroService> queue = new LinkedBlockingQueue<>(100);
			try {
				queue.put(m);
			}
			catch (InterruptedException e) {

			}
			broadcasts.put(type, queue);
			System.out.println(m.getName()+" Subscribed to "+type.getName());
		}
	}

	@Override
	public <T> void complete(Event<T> e, T result) {
		//get future and resolve it (which will notifyAll)
		Future<T> f = futureList.get(e);
		f.resolve(result);
		//we are done with event so delete future
		futureList.remove(e);

	}

	@Override
	public void sendBroadcast(Broadcast b) {
		if (!broadcasts.containsKey(b.getClass())) {
			broadcasts.put(b.getClass(), new LinkedBlockingQueue<>());
		}
		synchronized (broadcasts.get(b.getClass())) {
			if (broadcasts.containsKey(b.getClass()) && !broadcasts.get(b.getClass()).isEmpty()) {
				for (MicroService service : broadcasts.get(b.getClass())) {
					serviceList.get(service).add(b);
				}
			}
		}
	}


	@Override
	public <T> Future<T> sendEvent(Event<T> e) {

		Future<T> future = new Future<>();

			if (!events.containsKey(e.getClass()) || events.get(e.getClass()).isEmpty()) {
				return null;
			} else {
				synchronized (futureList) {
					synchronized (events) {
						MicroService next = null;
						try {
							next = events.get(e.getClass()).take();
						} catch (InterruptedException ex) {
							ex.printStackTrace();
						}
						serviceList.get(next).add(e);
						try {
							events.get(e.getClass()).put(next);
						} catch (InterruptedException ex) {
							ex.printStackTrace();
						}
					}
					futureList.put(e, future);
					return future;
				}
			}

	}

	@Override
	public void register(MicroService m) {
		if(!serviceList.containsKey(m)){
			LinkedBlockingQueue<Message> q = new LinkedBlockingQueue<>();
			serviceList.put(m,q);
		}
	}

	@Override
	public void unregister(MicroService m) {
		for(Enumeration <LinkedBlockingQueue<MicroService>> e = events.elements(); e.hasMoreElements();)
		{
			LinkedBlockingQueue<MicroService> q = e.nextElement();
			if(q.contains(m)) {
				q.remove(m);
			}
		}

		for(Enumeration <LinkedBlockingQueue<MicroService>> e = broadcasts.elements(); e.hasMoreElements();)
		{
			LinkedBlockingQueue<MicroService> q = e.nextElement();
			if(q.contains(m)) {
				q.remove(m);
			}
		}

		serviceList.remove(m);
	}

	@Override
	public Message awaitMessage(MicroService m) throws InterruptedException {
		// TODO Auto-generated method stub
		Message msg =  serviceList.get(m).take();

		return msg;
	}

	public static MessageBusImpl getInstance(){
		if (bus == null)
			bus = new MessageBusImpl();
		return bus;
	}


}
