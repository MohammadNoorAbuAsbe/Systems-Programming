package bgu.spl.mics.application.services;

import bgu.spl.mics.Future;
import bgu.spl.mics.MessageBusImpl;
import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.messages.*;
import bgu.spl.mics.application.objects.Model;
import bgu.spl.mics.application.objects.RunningCounter;
import bgu.spl.mics.application.objects.Student;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 * Student is responsible for sending the {@link TrainModelEvent},
 * {@link TestModelEvent} and {@link PublishResultsEvent}.
 * In addition, it must sign up for the conference publication broadcasts.
 * This class may not hold references for objects which it is not responsible for.
 *
 * You can add private fields and public methods to this class.
 * You MAY change constructor signatures and even add new public constructors.
 */
public class StudentService extends MicroService {
	
	Student student;
	LinkedList<Model> model;
    LinkedList<Future<Model>> trainedFutures;
    LinkedList<Future<Model>> testedFutures;
    public StudentService(String name, Student student, LinkedList<Model> model) {
        super("StudentService" + name);
        System.out.println("Building StudentService: "+getName());
        this.student = student;
        this.model = model;
        trainedFutures = new LinkedList<Future<Model>>();
        testedFutures = new LinkedList<Future<Model>>();
    }

    @Override
    protected void initialize() {

        for(Model m: model){
            trainModel(m);
            testModel(m);
            publishResult(m);
        }

        System.out.println("running StudentService: " + getName());
        this.subscribeBroadcast(TickBroadcast.class, tick ->{
            if(tick.getTime() == -1){
                RunningCounter.getInstance().reduceRunningThread();
                terminate();
            }else{
                if(!trainedFutures.isEmpty()){
                    for(Future<Model> future: trainedFutures){

                        if (future.isDone()){
                            testModel(future.get());
                            trainedFutures.remove(future);
                        }
                    }
                }

                if(!testedFutures.isEmpty()){
                    for(Future<Model> future: testedFutures){
                        if (future.isDone()){
                            if(future.get().isGood()){
                                publishResult(future.get());
                                future.get().publish();
                            }
                            testedFutures.remove(future);
                        }
                    }
                }
            }
        });

        this.subscribeBroadcast(PublishConferenceBroadcast.class, broad->{
            student.addPapersRead(broad.getModelNames().size()-student.getPublications());
        });
    }
    
    // send events
    public synchronized void trainModel(Model model) {
        System.out.println("training model "+ model.getName());
    	TrainModelEvent event = new TrainModelEvent(model);

        Future<Model> future = MessageBusImpl.getInstance().sendEvent(event);
        if(future == null){

            return;
        }
        trainedFutures.add(future);
    }
    
    public void testModel(Model model) {
        System.out.println("testing model "+ model.getName());
        TestModelEvent event = new TestModelEvent(model);
        Future<Model> future = MessageBusImpl.getInstance().sendEvent(event);
        if(future == null){

            return;
        }
        testedFutures.add(future);
    }

    public void publishResult(Model model) {
        System.out.println("publishing result model "+ model.getName());
        PublishResultsEvent event = new PublishResultsEvent(model);
        MessageBusImpl.getInstance().sendEvent(event);

        student.addPublications(1);
    }
}
