package bgu.spl.mics.application.objects;


public class RunningCounter {
    private static RunningCounter instance = null;
    private int running;

    public static RunningCounter getInstance() {
        if (instance == null) {
            instance = new RunningCounter();
        }
        return instance;
    }


    public RunningCounter() {
        this.running = 0;
    }

    public synchronized int getNumberRunningThreads() {
        return running;
    }

    public synchronized void addRunningThread() {
        running++;
    }

    public synchronized void reduceRunningThread() {
        running--;
    }
}
