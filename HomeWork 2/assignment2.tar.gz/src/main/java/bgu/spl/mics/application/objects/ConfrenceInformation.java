package bgu.spl.mics.application.objects;

import java.util.LinkedList;

/**
 * Passive object representing information on a conference.
 * Add fields and methods to this class as you see fit (including public methods and constructors).
 */
public class ConfrenceInformation {

    private String name;
    private int date;
    private LinkedList<String> modelNames;

    public ConfrenceInformation(String name, int date, LinkedList<String> modelNames) {
        this.name = name;
        this.date = date;
        this.modelNames = modelNames;

    }

    //maybe we will use this, if not this has to be deleted
    ////////////////////////////////////////////////////////////
    public ConfrenceInformation(String name, int date) {
        this.name = name;
        this.date = date;
        this.modelNames = new LinkedList<String>();

    }

    public void AddModelName(String name) {
        modelNames.add(name);
    }

    //////////////////////////////////////////////////////////

    public int getDate() {
        return date;
    }

    public String getName() {
        return name;
    }

    public String toString(){
        String tostring = "Confrence Name: "+name+"\n";
        tostring += "Published Models: \n";
        for(String s: modelNames){
            tostring += "\t"+s+"\n";
        }
        return tostring;
    }

    public LinkedList<String> getModelNames() {
        return modelNames;
    }
}
