package bgu.spl.mics.application.objects;

import java.util.ArrayList;

public class Statistics {
    private ArrayList<String> trainedModelNames;
    private int totalBatchesProccesed;
    private int cpuUsedTimeUnits;
    private int gpuUsedTimeUnits;

    public Statistics(){
        trainedModelNames = new ArrayList<>();
        totalBatchesProccesed = 0;
        gpuUsedTimeUnits = 0;
        cpuUsedTimeUnits = 0;
    }

    public void addTrainedModelName(String name){
        trainedModelNames.add(name);
    }
    public void addProccesed(int batchesProccesed){
        totalBatchesProccesed += batchesProccesed;
    }

    public void addCpuTime(int cpuTimeUnits){
        cpuUsedTimeUnits += cpuTimeUnits;
    }

    public int getCpuUsedTimeUnits() {
        return cpuUsedTimeUnits;
    }

    public int getGpuUsedTimeUnits() {
        return gpuUsedTimeUnits;
    }

    public int getTotalBatchesProccesed() {
        return totalBatchesProccesed;
    }

    public void addGpuTime(int gpuTimeUnits){
        gpuUsedTimeUnits += gpuTimeUnits;
    }
}
