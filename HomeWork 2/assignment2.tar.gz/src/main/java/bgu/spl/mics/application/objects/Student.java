package bgu.spl.mics.application.objects;

import bgu.spl.mics.MessageBusImpl;
import bgu.spl.mics.application.messages.TestModelEvent;
import bgu.spl.mics.application.messages.TrainModelEvent;

import java.util.LinkedList;

enum Degree {
        MSc, PhD
    }
/**
 * Passive object representing single student.
 * Add fields and methods to this class as you see fit (including public methods and constructors).
 */
public class Student {
    /**
     * Enum representing the Degree the student is studying for.
     */

    private String name;
    private String department;
    private Degree status;
    private int publications; //number of published results (increases when the conference publishes the student results, not when the student sends the event).
    private int papersRead; // number of publications received from conferences, excluding his own.

    private LinkedList<Model> trainedModels;
    
    public Student(String name, String department, String status) {
 
        this.status = toDegree(status);
    	this.name = name;
    	this.department = department;
    	publications = 0;
    	papersRead = 0;
        trainedModels = new LinkedList<Model>();
    }

    private Degree toDegree(String status){
        if(status.equals("MSc"))
            return Degree.MSc;
        else
            return Degree.PhD;
    }

    public String getName() {
        return name;
    }

    public void addPublications(int toAdd){
        publications += toAdd;
    }
    public void addPapersRead(int toAdd){
        papersRead += toAdd;
    }

    public String getType() {
        return status.toString();
    }

    public int getPublications() {
        return publications;
    }

    public String toString(){
        String tostring = name+":\n";
        tostring += "\tTrained Models:\n";
        for(Model m: trainedModels){
            tostring += "\t\t"+m.toString()+"\n";
        }
        tostring += "\tPublished Models:\n";
        for(Model m: trainedModels){
            if(m.isPublished())
                tostring += "\t\t"+m.toString()+"\n";
        }
        tostring += "Papers Read: "+papersRead;
        return tostring;
    }
}
