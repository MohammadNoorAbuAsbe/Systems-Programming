package bgu.spl.mics.application.services;

import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.messages.TestModelEvent;
import bgu.spl.mics.application.messages.TickBroadcast;
import bgu.spl.mics.application.messages.TrainModelEvent;
import bgu.spl.mics.application.objects.DataBatch;
import bgu.spl.mics.application.objects.GPU;
import bgu.spl.mics.application.objects.RunningCounter;

import java.util.ArrayList;


/**
 * GPU service is responsible for handling the
 * {@link TrainModelEvent} and {@link TestModelEvent},
 * This class may not hold references for objects which it is not responsible for.
 *
 * You can add private fields and public methods to this class.
 * You MAY change constructor signatures and even add new public constructors.
 */
public class GPUService extends MicroService {
    private GPU gpu;

    public GPUService(String name, GPU gpu) {
        super(name);
        System.out.println("Building GPUService: "+getName());
        this.gpu = gpu;
    }

    @Override
    protected void initialize() {
        System.out.println("running GPUService: " + getName());
        this.subscribeBroadcast(TickBroadcast.class, tick ->{
                if (tick.getTime() == -1){
                    RunningCounter.getInstance().reduceRunningThread();
                    terminate();
                }
        });

        this.subscribeEvent(TrainModelEvent.class, event ->{
            System.out.println("got train request");
            if(!event.isDone()){
                if(!event.isTraining()){
                    gpu.updateModel(event.getModel());
                    gpu.AddBatches();
                    event.getModel().advanceTraining();
                    gpu.startProccessing();
                    complete(event, event.getModel());
                }
            }

        });

        this.subscribeEvent(TestModelEvent.class, event->{

            String type = event.getModel().getStudent().getType();
            //good result chance
            float chanceForGood = 0.6f;
            if(type.equals("PhD"))
                chanceForGood = 0.8f;

            if(Math.random() < chanceForGood){
                event.TrainingWasGood();
            }else{
                event.TrainingWasBad();
            }
            complete(event, event.getModel());
        });
    }
}
