package bgu.spl.mics.application.services;

import bgu.spl.mics.Broadcast;
import bgu.spl.mics.MessageBusImpl;
import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.messages.PublishConferenceBroadcast;
import bgu.spl.mics.application.messages.PublishResultsEvent;
import bgu.spl.mics.application.messages.TickBroadcast;
import bgu.spl.mics.application.objects.ConfrenceInformation;
import bgu.spl.mics.application.objects.RunningCounter;

/**
 * Conference service is in charge of
 * aggregating good results and publishing them via the {@link PublishConfrenceBroadcast},
 * after publishing results the conference will unregister from the system.
 * This class may not hold references for objects which it is not responsible for.
 *
 * You can add private fields and public methods to this class.
 * You MAY change constructor signatures and even add new public constructors.
 */
public class ConferenceService extends MicroService {
    int date;
    ConfrenceInformation information;

    public ConferenceService(ConfrenceInformation information) {
        super(information.getName());
        System.out.println("Building ConferenceService: "+getName());
        date = information.getDate();
        this.information = information;
    }



    @Override
    protected void initialize() {
        System.out.println("running ConfrenceService: " + getName());
        //on date
        this.subscribeBroadcast(TickBroadcast.class, tick ->{
            if (tick.getTime() >= date) {
                System.out.println(getName() + "Publishing Resaults");
                Broadcast broadcast = new PublishConferenceBroadcast(information.getModelNames());
                sendBroadcast(broadcast);
                System.out.println(getName() + "Terminating");
                MessageBusImpl bus = MessageBusImpl.getInstance();
                bus.unregister(this);
                RunningCounter.getInstance().reduceRunningThread();
                terminate();
            }
        });

        this.subscribeEvent(PublishResultsEvent.class, event->{
                if(event.getModel().isGood()){
                    information.AddModelName(event.getModel().getName());
                }
        });
    }
}
