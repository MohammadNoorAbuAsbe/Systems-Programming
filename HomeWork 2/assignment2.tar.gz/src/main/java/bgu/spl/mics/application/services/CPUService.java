package bgu.spl.mics.application.services;

import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.messages.TickBroadcast;
import bgu.spl.mics.application.objects.CPU;
import bgu.spl.mics.application.objects.RunningCounter;

/**
 * This class may not hold references for objects which it is not responsible for.
 *
 * You can add private fields and public methods to this class.
 * You MAY change constructor signatures and even add new public constructors.
 */
public class CPUService extends MicroService {

    CPU cpu;

    public CPUService(String name, CPU cpu) {
        super("CPUService" + name);
        System.out.println("Building CPUService: "+getName());
        this.cpu = cpu;
    }

    @Override
    protected void initialize() {
        RunningCounter.getInstance().addRunningThread();
        System.out.println("running CPUService: " + getName());

        this.subscribeBroadcast(TickBroadcast.class, tick ->{

            if (tick.getTime() == -1){
                terminate();
            }else{
                cpu.startProcessing();
            }
        });

    }
}
