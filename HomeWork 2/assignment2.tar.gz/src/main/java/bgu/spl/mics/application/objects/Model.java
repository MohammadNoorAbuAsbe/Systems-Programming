package bgu.spl.mics.application.objects;

/**
 * Passive object representing a Deep Learning model.
 * Add all the fields described in the assignment as private fields.
 * Add fields and methods to this class as you see fit (including public methods and constructors).
 */
public class Model {
	
	private String name;
	private Data data;
	private Student student;

	private Boolean isPublished;


	private enum Status{PreTrained,Training,Trained,Tested;
		private static Status[] vals = values();
		private Status next()
		{
			return vals[(this.ordinal()+1) % vals.length];
		};
    }
	private enum Results{None,Good,Bad};	
	private Results results;
	private Status status;

	public Model(String name, Data data, Student student) {
		this.name = name;
		this.data = data;
		this.student = student;
		this.status = Status.PreTrained;
		this.results = Results.None;
		isPublished = false;
	}
	
	public void advanceTraining() {
		if (status != Status.Tested) {
			this.status = this.status.next();
		}
	}
	
	// could we find a better way? maybe
	public void TrainingWasBad() {
		if (results == Results.None) {
			this.results = Results.Bad;
		}
	}
	
	public void TrainingWasGood() {
		if (results == Results.None) {
			this.results = Results.Good;
		}
	}

	public boolean isTrained(){
		return status == Status.Trained;
	}

	public boolean isTraining(){
		return status == Status.Training;
	}

	public boolean isGood(){
		return results == Results.Good;
	}

	public void Train(){
		data.processBatch();
		if(data.getSize() == data.getProcessed() && isTraining()){
			advanceTraining();
		}
	}

	public Data getData(){
		return data;
	}

	public Student getStudent() {
		return student;
	}

	public void publish(){
		isPublished = true;
	}

	public Boolean isPublished() {
		return isPublished;
	}

	public String getName() {
		return name;
	}

	public String toString(){
		String tostring = "name: "+name+"\n";
		tostring += "Data: "+data.toString();
		return tostring;
	}

	public Results returnResults() {
		return results;
	}
	
	public String returnStatus() {
		return status.toString();
	}
	
	
}
