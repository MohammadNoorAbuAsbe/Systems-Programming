package bgu.spl.mics.application.objects;

import java.util.ArrayList;
import java.util.concurrent.LinkedBlockingQueue;

import static java.lang.Thread.sleep;


/**
 * Passive object representing a single GPU.
 * Add all the fields described in the assignment as private fields.
 * Add fields and methods to this class as you see fit (including public methods and constructors).
 */
public class GPU {



    /**
     * Enum representing the type of the GPU.
     */
    private enum Type {RTX3090, RTX2080, GTX1080}
	private LinkedBlockingQueue<DataBatch> disk;//for unproccesed batches doesnt have space limit
	private LinkedBlockingQueue<DataBatch> vRam;//for proccessed batches is limited by space determined by gpu type
    private Type type;
    private int sentBatches;
    private int currNumOfBatches;
    private int tickTime;
    ///temporary cluster should get instace in the function not the builder
    private Cluster c;
    //the current model;
    private Model currModel;

    public GPU(String type, int tickTime){
        c = Cluster.getInstance();
        this.type = toType(type);
        sentBatches = 0;
        currNumOfBatches = 0;
        this.tickTime = tickTime;
        disk = new LinkedBlockingQueue<>();
        vRam = new LinkedBlockingQueue<>();
    }

    public void updateModel(Model m){
        currModel = m;
    }

    public Model getCurrModel(){
        return currModel;
    }

    public void AddBatches() {
        int numOfBatches = currModel.getData().getSize()/1000;
        currNumOfBatches = numOfBatches;
        for(int i = 0; i < numOfBatches; i++){
            DataBatch toAdd = new DataBatch(currModel.getData(), i, this);
            disk.add(toAdd);
        }

    }

    public void startProccessing(){
        while(!disk.isEmpty() || !vRam.isEmpty()){
            if(vRam.remainingCapacity() > 0 && vRam.size()-1 > sentBatches && !disk.isEmpty()){
                sendUnproccesedBatch();
                sentBatches++;
            }
            proccess();
        }
    }

    public void addToVRam(DataBatch processedBatch){
        try {
            vRam.put(processedBatch);
        } catch (InterruptedException e) {
        }
    }
    public void proccess(){
            if(!currModel.isTrained() && !vRam.isEmpty()){
                try {
                    DataBatch batch = vRam.take(); //getbatch from vRam and train the model
                    switch (type){
                        case RTX3090:
                            sleep(tickTime);
                            c.updateGpuTotalTime(1);
                            break;
                        case RTX2080:
                            sleep(tickTime*2);
                            c.updateGpuTotalTime(2);
                            break;
                        case GTX1080:
                            sleep(tickTime*4);
                            c.updateGpuTotalTime(4);
                            break;
                    }
                    batch.getData().processBatch();
                    sentBatches--;

                } catch (InterruptedException e) {

                }
            }

    }
    public void sendUnproccesedBatch() {
        c = Cluster.getInstance();
        try {
            DataBatch batchToSend = disk.take();
            c.addBatch(this, batchToSend);
        } catch (InterruptedException e) {

        }
    }


    private Type toType(String type){
        if (type.equals("RTX3090")){
            vRam = new LinkedBlockingQueue<>(32);
            return Type.RTX3090;
        }else if (type.equals("RTX2080")){
            vRam = new LinkedBlockingQueue<>(16);
            return Type.RTX2080;
        }else {
            vRam = new LinkedBlockingQueue<>(8);
            return Type.GTX1080;
        }
    }
}
