package bgu.spl.mics.application.objects;

import java.util.concurrent.LinkedBlockingQueue;

import static java.lang.Thread.sleep;

/**
 * Passive object representing a single CPU.
 * Add all the fields described in the assignment as private fields.
 * Add fields and methods to this class as you see fit (including public methods and constructors).
 */
public class CPU {
	private int cores;
 	private LinkedBlockingQueue<DataBatch> data;
 	private Cluster cluster;
	private int tickTime;

	//added
	private int estimatedTime;

	public int getEstimatedTime(){
		return estimatedTime;
	}

	 public CPU( int cores, int tickTime){
		 this.cores = cores;
		 data = new LinkedBlockingQueue<>();
		 cluster = Cluster.getInstance();
		 this.tickTime = tickTime;
		 //added
		 estimatedTime = 0;
	 }

	 public void startProcessing(){

			while(!data.isEmpty()){
				try {
					process(data.take());
				} catch (InterruptedException e) {

				}
			}


	 }

	 public void process(DataBatch batch) throws InterruptedException {cluster = Cluster.getInstance();
		sleep((32/cores)*batch.getData().getProcessTime()*tickTime);
		cluster.addProccessedBatch(batch);
		cluster.updateCpuTotalTime((32/cores)*batch.getData().getProcessTime()*tickTime);
		//added
		estimatedTime -= (32/cores)*batch.getData().getProcessTime()*tickTime;
		 cluster.UpdateEstimatedTime(this, false);
	 }

	 public void addData(DataBatch dataBatch){
		 try {
			 data.put(dataBatch);
			 //added
			 estimatedTime += (32/cores)*dataBatch.getData().getProcessTime()*tickTime;
			 cluster.UpdateEstimatedTime(this, true);
		 } catch (InterruptedException e) {

		 }
	 }

}
