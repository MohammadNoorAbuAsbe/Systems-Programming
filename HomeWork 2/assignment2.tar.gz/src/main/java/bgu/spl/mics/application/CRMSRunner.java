package bgu.spl.mics.application;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import bgu.spl.mics.MessageBusImpl;
import bgu.spl.mics.application.objects.*;
import bgu.spl.mics.application.services.*;
import com.google.gson.*;

/** This is the Main class of Compute Resources Management System application. You should parse the input file,
 * create the different instances of the objects, and run the system.
 * In the end, you should output a text file.
 */
public class CRMSRunner {
    public static void main(String[] args) {
        ConcurrentHashMap<Student, LinkedList<Model>> studentList = new ConcurrentHashMap<>();
        LinkedList<Student> students = new LinkedList<>();
        ArrayList<GPU> gpuList = new ArrayList<>();
        ArrayList<CPU> cpuList = new ArrayList<>();
        ArrayList<ConfrenceInformation> confrencesList = new ArrayList<>();

        int tickTime = 0;
        int duration = 0;

        Cluster cluster = Cluster.getInstance();
        MessageBusImpl bus = MessageBusImpl.getInstance();


        //File input = new File(args[0]);
        File input = new File("example_input.json");
        try{
       		JsonElement fileElement = JsonParser.parseReader(new FileReader(input));
			JsonObject fileObject = fileElement.getAsJsonObject();

            tickTime = fileObject.get("TickTime").getAsInt();
            duration = fileObject.get("Duration").getAsInt();

			//extracting fields
			JsonArray jsonArrayOfStudents = fileObject.get("Students").getAsJsonArray();

            //building students and models
			for(JsonElement studentElement : jsonArrayOfStudents){
                //get the jsonObject
                JsonObject studentJsonObject = studentElement.getAsJsonObject();
                
                String name = studentJsonObject.get("name").getAsString();
                String department = studentJsonObject.get("department").getAsString();
                //System.out.println(name +" "+ department);
				String status = studentJsonObject.get("status").getAsString();
				Student s = new Student(name, department, status);

				LinkedList<Model> models = new LinkedList<Model>();
				JsonArray jsonArrayOfModels = studentJsonObject.get("models").getAsJsonArray();
			
				for(JsonElement modelElement : jsonArrayOfModels){
                    
                    JsonObject modedlJsonObject = modelElement.getAsJsonObject();
                    
                    String model_name = modedlJsonObject.get("name").getAsString();
                    String type = modedlJsonObject.get("type").getAsString();
                    int size = modedlJsonObject.get("size").getAsInt();
                    
                    models.add(new Model(model_name, new Data(type, size), s));
				}
				studentList.put(s,models);
                students.add(s);
            }

            //build gpuList
            JsonArray jsonArrayOfGPUs = fileObject.get("GPUS").getAsJsonArray();

            for(JsonElement gpuElement : jsonArrayOfGPUs) {
                //get the jsonObject
                String type = gpuElement.getAsString();
                gpuList.add(new GPU(type, tickTime));
            }

            //build cpuList
            JsonArray jsonArrayOfCPUs = fileObject.get("CPUS").getAsJsonArray();

            for(JsonElement cpuElement : jsonArrayOfCPUs) {
                //get the jsonObject

                int cores = cpuElement.getAsInt();
                cpuList.add(new CPU(cores, tickTime));
            }

            //build confrencesList
            JsonArray jsonArrayOfConferences = fileObject.get("Conferences").getAsJsonArray();

            //building students and models
            for(JsonElement ConferenceElement : jsonArrayOfConferences) {
                //get the jsonObject
                JsonObject ConferenceJsonObject = ConferenceElement.getAsJsonObject();
                String name = ConferenceJsonObject.get("name").getAsString();
                int date = ConferenceJsonObject.get("date").getAsInt();

                confrencesList.add(new ConfrenceInformation(name, date));

            }

            System.out.println(tickTime+","+duration);

		} catch(FileNotFoundException e){
            e.printStackTrace();
        }


        //link everything
        //-----------------StudentServices------------------
        ArrayList<Thread> studentServices = new ArrayList<>();
        for(Student s: students){
            StudentService toAdd = new StudentService("studentService" + s.getName(),s, studentList.get(s));
            bus.register(toAdd);
            studentServices.add(new Thread(toAdd));
        }
        //-----------------GPUServices------------------
        ArrayList<Thread> GPUServices = new ArrayList<>();
        Iterator gpuIterator = gpuList.iterator();
        while(gpuIterator.hasNext()){
            GPU gpu = (GPU)gpuIterator.next();
            GPUService toAdd = new GPUService("GPUService" + gpuList.indexOf(gpu) ,gpu);
            GPUServices.add(new Thread(toAdd));
            bus.register(toAdd);
        }

        //-----------------CPUServices------------------
        ArrayList<Thread> CPUServices = new ArrayList<>();
        Iterator cpuIterator = cpuList.iterator();
        while(cpuIterator.hasNext()){
            CPU cpu = (CPU)cpuIterator.next();
            CPUService toAdd = new CPUService("CPUService" + cpuList.indexOf(cpu) ,cpu);
            CPUServices.add(new Thread(toAdd));
            bus.register(toAdd);

        }

        //-----------------ConferenceServices------------------
        ArrayList<Thread> ConferenceServices = new ArrayList<>();
        Iterator conferenceIterator = confrencesList.iterator();
        while(conferenceIterator.hasNext()){
            ConfrenceInformation information = (ConfrenceInformation)conferenceIterator.next();
            ConferenceService toAdd = new ConferenceService(information);
            ConferenceServices.add(new Thread(toAdd));
            bus.register(toAdd);

        }

        //-----------------TimeService------------------
        TimeService timeService= new TimeService(tickTime, duration);
        Thread timer= new Thread(timeService);
        bus.register(timeService);

        ExecutorService taskExecutor = Executors.newFixedThreadPool(studentServices.size() + CPUServices.size() + GPUServices.size() + ConferenceServices.size());
        //-------------Running StudentServices--------------
        for (int i = 0; i < studentServices.size(); i++) {
            System.out.println("starting Student service " + i);
            //studentServices.get(i).start();
            taskExecutor.execute(studentServices.get(i));

        }

        //------------Running GPUServices--------
        for (int i = 0; i < GPUServices.size(); i++) {
            System.out.println("starting GPU Service " + i);
            //GPUServices.get(i).start();
            taskExecutor.execute(GPUServices.get(i));

        }

        //------------Running CPUServices------
        for (int i = 0; i < CPUServices.size(); i++) {
            System.out.println("starting CPU Service " + i);
           //CPUServices.get(i).start();
            taskExecutor.execute(CPUServices.get(i));
        }

        //-------------Running ConferenceServices-----------
        for (int i = 0; i < ConferenceServices.size(); i++) {
            System.out.println("starting confrence Service " + i);
            //ConferenceServices.get(i).start();
            taskExecutor.execute(ConferenceServices.get(i));
        }

        //-----------Running timeService----------

        //int numOfServices = studentServices.size() + CPUServices.size() + GPUServices.size() + ConferenceServices.size();
        //while (RunningCounter.getInstance().getNumberRunningThreads() < numOfServices){
            //System.out.println(RunningCounter.getInstance().getNumberRunningThreads());
        //}

        System.out.println("starting timer");
        //timer.start();
        //taskExecutor.execute(timer);
        taskExecutor.shutdown();
        //taskExecutor.shutdownNow();
        try {
            taskExecutor.awaitTermination(10, TimeUnit.NANOSECONDS);
            timer.run();
        } catch (InterruptedException e) {

        }
        //timer.run();
        System.out.println("after timer");


        //wtf is this
        taskExecutor.shutdown();
        //taskExecutor.shutdownNow();
        try {
            taskExecutor.awaitTermination(10, TimeUnit.NANOSECONDS);
        } catch (InterruptedException e) {

        }







        //-----------------Output---------------------

        File myObj = new File("output.txt");
        try {
            if (myObj.createNewFile()) {
                System.out.println("File created: " + myObj.getName());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {

        }

        FileWriter myWriter = null;
        try {
            myWriter = new FileWriter("output.txt");

            for(Student s: students){
                myWriter.write(s.toString());
            }

            for(ConfrenceInformation con :confrencesList){
                myWriter.write(con.toString());
            }
            myWriter.write("GPU Time: "+(tickTime*cluster.getStatistics().getGpuUsedTimeUnits()));
            myWriter.write("CPU Time: "+(tickTime*cluster.getStatistics().getCpuUsedTimeUnits()));
            myWriter.write("Amount of batches processed by the CPUs"+cluster.getStatistics().getTotalBatchesProccesed());
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {

        }

    }
}
