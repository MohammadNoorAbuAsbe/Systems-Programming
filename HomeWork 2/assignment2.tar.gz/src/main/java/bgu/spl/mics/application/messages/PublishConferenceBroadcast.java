package bgu.spl.mics.application.messages;

import bgu.spl.mics.Broadcast;
import bgu.spl.mics.Event;
import bgu.spl.mics.application.objects.Model;

import java.util.LinkedList;

public class PublishConferenceBroadcast implements Broadcast {
    LinkedList<String> modelNames;
    public PublishConferenceBroadcast(LinkedList<String> modelNames) {
        this.modelNames = modelNames;
    }

    public LinkedList<String> getModelNames(){
        return modelNames;
    }
}
