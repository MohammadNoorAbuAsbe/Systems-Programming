package bgu.spl.mics.application.objects;

import bgu.spl.mics.MicroService;

import java.util.LinkedList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;


/**
 * Passive object representing the cluster.
 * <p>
 * This class must be implemented safely as a thread-safe singleton.
 * Add all the fields described in the assignment as private fields.
 * Add fields and methods to this class as you see fit (including public methods and constructors).
 */
public class Cluster {

	private LinkedList<GPU> gpuList;

	private Statistics statistics;

	private LinkedBlockingQueue<DataBatch> unproccessedData;
	private LinkedList<CPU> CPUsInOrder;

	private static Cluster cluster;

	private Cluster(){
		unproccessedData = new LinkedBlockingQueue<DataBatch>();
		CPUsInOrder = new LinkedList<CPU>();
		gpuList = new LinkedList<GPU>();
		statistics = new Statistics();
	}
	
	/**
     * Retrieves the single instance of this class.
     */
	public static Cluster getInstance() {
		//TODO: Implement this
		if(cluster == null)
			cluster = new Cluster();
		return cluster;
	}


	public void addGpu(GPU gpu){
		gpuList.add(gpu);
	}
	public void addCpu(CPU cpu){
		CPUsInOrder.add(cpu);
	}

	public void addBatch(GPU gpu, DataBatch batch){
		unproccessedData.add(batch);
		sendDataToCPUs();
	}

	public void sendDataToCPUs(){
		try {
			System.out.println("sending unprocessed");
			DataBatch dataBatch = unproccessedData.take();
			CPUsInOrder.getFirst().addData(dataBatch);
		} catch (InterruptedException e) {
		}

	}

	public void UpdateEstimatedTime(CPU cpu, boolean added){
		int index = CPUsInOrder.indexOf(cpu);
		if (added) {
			while (index + 1 < CPUsInOrder.size() && cpu.getEstimatedTime() > CPUsInOrder.get(index + 1).getEstimatedTime())
			{
				CPUsInOrder.set(index, CPUsInOrder.get(index + 1));
				CPUsInOrder.set(index + 1, cpu);
				index++;
			}
		}
		else {
			while (index - 1 <= 0 && cpu.getEstimatedTime() < CPUsInOrder.get(index - 1).getEstimatedTime())
			{
				CPUsInOrder.set(index, CPUsInOrder.get(index - 1));
				CPUsInOrder.set(index - 1, cpu);
				index--;
			}
		}

	}

	public void addProccessedBatch(DataBatch batch) {
		System.out.println("Adding batch to Vram");
		batch.getGpu().addToVRam(batch);
		statistics.addProccesed(1);

	}

	public void updateGpuTotalTime(int tick) {
		statistics.addGpuTime(tick);
	}

	public void updateCpuTotalTime(int tick) {
		statistics.addCpuTime(tick);
	}

	public Statistics getStatistics() {
		return statistics;
	}
}
